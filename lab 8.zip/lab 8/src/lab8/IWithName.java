package lab8;

interface IWithName{
    String getName();
}

public class drawer {
    private static void drawLine(int n, char ch) {
    }
    public static void drawPyramid(int n) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n - i; j++) {
                System.out.print(".");
            }
            for (int k = 1; k <= 2 * i - 1; k++) {
                System.out.print("X");
            }
            for (int j = 1; j <= n - i; j++) {
                System.out.print(".");
            }
            System.out.println();
        }
    }

    public static void drawChristmassTree(int n) {
        int w = n*2-1;
        if (n <= 2){
            for (int i = 0; i <= 1; i++) {
                System.out.print(".");
                System.out.print("X");
                System.out.print(".");
                System.out.println();
            }
            System.out.println("XXX");
            System.out.println();
        }else {
            for (int i = 0; i <= 1; i++) {
                for (int j = 0; j < w / 2; j++)
                    System.out.print(".");
                System.out.print("X");
                for (int j = 0; j < w / 2; j++)
                    System.out.print(".");
                System.out.println();
            }
            for (int j = 0; j < (w - 2) / 2; j++)
                System.out.print(".");
            System.out.print("XXX");
            for (int j = 0; j < (w - 2) / 2; j++)
                System.out.print(".");
            System.out.println();
        }
        for (int j = n-3; j >= 0; j--){
            for (int i = 0; i < Math.abs(j-n); i++) {
                for (int k = 0; k < n-i-1; k++){
                    System.out.print(".");
                }
                for (int k = 0; k < 2*i+1; k++){
                    System.out.print("X");
                }
                for (int k = 0; k < n-i-1; k++){
                    System.out.print(".");
                }
                System.out.println();
            }
        }
    }
}
if(rows==1) {
        System.out.print("x");
        }else{
        for(int n=1;n<=rows;n++){
        for(int i=1;i<=rows;i++){
        for(int k=1;k<rows;k++){
        System.out.print(".");
        }
        for(int g=0;g<(2*i-1);g++){
        System.out.print("x");
        }
        System.out.println();
        }
        }
        }
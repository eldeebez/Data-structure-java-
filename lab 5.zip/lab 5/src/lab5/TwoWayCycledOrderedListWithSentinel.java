package lab5;

import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TwoWayCycledOrderedListWithSentinel<E> implements IList<E> {

    private class Element {
        public Element(E e) {
            this.object = e;
        }

        public Element(E e, Element next, Element prev) {
            this.object = e;
            this.next = next;
            this.prev = prev;
        }

        // add element e after this
        public void addAfter(Element elem) {
            this.next.prev = elem;
            elem.next = this.next;
            this.next = elem;
            elem.prev = this;
        }

        public void addBefore(Element elem) {
            this.prev.next = elem;
            elem.prev = this.prev;
            this.prev = elem;
            elem.next = this;
        }

        // assert it is NOT a sentinel
        public void remove() {
            if (this != sentinel) {
                this.prev.next = this.next;
                this.next.prev = this.prev;
            }
        }

        E object;
        Element next = null;
        Element prev = null;
    }


    Element sentinel;
    int size;

    private class InnerIterator implements Iterator<E> {
        Element pos;

        public InnerIterator() {
            pos = sentinel;
        }

        @Override
        public boolean hasNext() {
            return pos.next != sentinel;
        }

        @Override
        public E next() {
            pos = pos.next;
            return pos.object;
        }
    }

    private class InnerListIterator implements ListIterator<E> {
        Element pos;

        public InnerListIterator() {
            pos = sentinel;
        }

        @Override
        public boolean hasNext() {
            return pos.next != sentinel;
        }

        @Override
        public E next() {
            pos = pos.next;
            return pos.object;
        }

        @Override
        public void add(E arg0) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean hasPrevious() {
            return pos.prev != sentinel;
        }

        @Override
        public int nextIndex() {
            throw new UnsupportedOperationException();
        }

        @Override
        public E previous() {
            pos = pos.prev;
            return pos.object;
        }

        @Override
        public int previousIndex() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void set(E arg0) {
            throw new UnsupportedOperationException();
        }
    }

    public TwoWayCycledOrderedListWithSentinel() {
        sentinel = new Element(null);
        sentinel.next = sentinel;
        sentinel.prev = sentinel;
        size = 0;
    }

    //@SuppressWarnings("unchecked")
    @Override
    public boolean add(E e) {
//        if(!Document.isCorrectId(((Link)e).ref) || ((Link)e).weight<=0) {
//            return false;
//        }
        if (size == 0) {
            Element element = new Element(e);
            sentinel.next = element;
            sentinel.prev = element;
            element.prev = sentinel;
            element.next = sentinel;
            size++;
            return true;
        }
//        System.out.println("essssssssa");
//        System.out.println(size);
        for (int i = 0; i < size; i++) {
            if (((Link) e).compareTo((Link) get(i)) < 0) {
                getElement(i).addBefore(new Element(e));
                size++;
                return true;
            }
        }
        getElement(size - 1).addAfter(new Element(e));
        size++;
        return true;
    }

    private Element getElement(int index) throws NoSuchElementException {
        if (index < 0 || index >= size) {
            throw new NoSuchElementException();
        }
        Element currentElement = sentinel;
        for (int i = 0; i < size; i++) {
            currentElement = currentElement.next;
            if (i == index) {
                return currentElement;
            }
        }
        throw new NoSuchElementException();
    }

    private Element getElement(E obj) throws NoSuchElementException {
        if (!contains(obj)) {
            return null;
        }
        int i = indexOf(obj);
        return getElement(i);
    }

    @Override
    public void add(int index, E element) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void clear() {
        sentinel.next = sentinel;
        sentinel.prev = sentinel;
        size = 0;
    }

    @Override
    public boolean contains(E element) {
        return indexOf(element) != -1;
    }

    @Override
    public E get(int index) throws NoSuchElementException {
        return getElement(index).object;
    }

    @Override
    public E set(int index, E element) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int indexOf(E element) {
        Element currentElement = sentinel;
        for (int i = 0; i < size; i++) {
            currentElement = currentElement.next;
            if (get(i).equals(element)) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public Iterator<E> iterator() {
        return new InnerIterator();
    }

    @Override
    public ListIterator<E> listIterator() {
        return new InnerListIterator();
    }

    @Override
    public E remove(int index) {
        Element deletedElement = getElement(index);
        deletedElement.remove();
        size--;
        return deletedElement.object;
    }

    @Override
    public boolean remove(E e) {
        Element element = getElement(e);
        if (element == null) {
            return false;
        }
        element.remove();
        size--;
        return true;
    }

    @Override
    public int size() {
        return size;
    }

    //@SuppressWarnings("unchecked")
    public void add(TwoWayCycledOrderedListWithSentinel<E> other) {
        if (other == this || other.isEmpty()) {
            return;
        }
        if (this.isEmpty()) {
            sentinel.next = other.getElement(0);
            other.getElement(0).prev = sentinel;
            sentinel.prev = other.getElement(other.size-1);
            other.getElement(other.size-1).next = sentinel;
            size = other.size;
            other.clear();
            return;
        }
        Element currentElement = sentinel;
        while (currentElement.next != sentinel) {
            currentElement = currentElement.next;
            if (((Link) other.get(0)).compareTo((Link) currentElement.object) < 0) {
                Element addedElement = other.getElement(0);
                other.remove(0);
                currentElement.addBefore(addedElement);
                size++;
                if (other.isEmpty()) {
                    return;
                }
                currentElement = currentElement.prev;
            }
        }
        if (!(other.isEmpty())) {
            Element lastElement = getElement(size - 1);
            Element addedElement = other.getElement(0);
            Element otherLastElement = other.getElement(other.size - 1);
            lastElement.next = addedElement;
            addedElement.prev = lastElement;
            otherLastElement.next = sentinel;
            sentinel.prev = otherLastElement;
            size += other.size;
            other.clear();
        }

    }

    //@SuppressWarnings({ "unchecked", "rawtypes" })
    public void removeAll(E e) {
        if (isEmpty()) {
            return;
        }
        if (!contains(e)) {
            return;
        }
        int index = 0;
        while (index < size && ((Link) e).compareTo((Link) get(index)) >= 0) {
            if (e.equals(get(index))) {
                remove(index);
            } else {
                index++;
            }
        }

    }
}


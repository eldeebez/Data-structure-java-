package lab5;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Document {
    public String name;
    public TwoWayCycledOrderedListWithSentinel<Link> link;

    public Document(String name, Scanner scan) {
        this.name = name.toLowerCase();
        link = new TwoWayCycledOrderedListWithSentinel<Link>();
        load(scan);
    }

    public void load(Scanner scan) {
        while (scan.hasNextLine()) {
            String s = scan.nextLine().toLowerCase();
            if (s.equalsIgnoreCase("eod")) {
                return;
            }
            String[] words = s.split(" ");
            for (String word : words) {
                if (word.startsWith("link=")) {
                    Pattern weightPattern = Pattern.compile("\\(\\d+\\)$");
                    Matcher matcher = weightPattern.matcher(word);
                    boolean found = matcher.find();
                    if (found) {
                        if (isCorrectId(word.substring(5, matcher.start()))) {
                            link.add(createLink(word.substring(5)));
                        }
                    } else {
                        if (isCorrectId(word.substring(5))) {
                            link.add(createLink(word.substring(5)));
                        }
                    }
                }
            }
        }
    }


    public static boolean isCorrectId(String id) {
        if (id.length() == 0) {
            return false;
        }
//        System.out.println("id " + id);
        if (Character.isLetter(id.charAt(0))) {
            for (int i = 1; i < id.length(); i++) {
                char ch = id.charAt(i);
                if (!Character.isLetter(ch) && !Character.isDigit(ch) && (int) ch != 95) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    // accepted only small letters, capitalic letter, digits and '_' (but not on the begin)
    public static Link createLink(String link) {
        Pattern weightPattern = Pattern.compile("\\(\\d+\\)$");
        Matcher matcher = weightPattern.matcher(link);
        boolean found = matcher.find();
        if (found) {
            return new Link(link.substring(0, matcher.start()), Integer.parseInt(link.substring(matcher.start() + 1, link.length() - 1)));
        } else {
            return new Link(link);
        }
    }

    @Override
    public String toString() {
        String retStr = "Document: " + name;
        if (link.isEmpty()) {
            return retStr;
        }
        Iterator<Link> iterator = link.iterator();
        retStr += "\n";
        int counter = 0;
        while (iterator.hasNext()) {
            retStr += iterator.next().toString() + " ";
            counter++;
            if (counter == 10) {
                counter = 0;
                retStr = retStr.substring(0, retStr.length() - 1);
                retStr += "\n";
            }
        }
        return retStr.trim();
    }

    public String toStringReverse() {
        String retStr = "Document: " + name;
        if (link.isEmpty()) {
            return retStr;
        }
        ListIterator<Link> iter = link.listIterator();
        Link last = null;
        while (iter.hasNext()) {
            last = iter.next();
        }
        retStr += "\n";
        retStr += last.toString() + " ";
        int counter = 1;
        while (iter.hasPrevious()) {
            retStr += iter.previous().toString() + " ";
            counter++;
            if (counter == 10) {
                counter = 0;
                retStr = retStr.substring(0, retStr.length() - 1);
                retStr += "\n";
            }
        }
        return retStr.trim();
    }

    public int[] getWeights() {
        int[] weights_arr = new int[link.size];
        for (int i = 0; i < link.size; i++) {
            weights_arr[i] = link.get(i).weight;
        }
        return weights_arr;
    }

    public static void showArray(int[] arr) {
        String str = "";
        for (int i = 0; i < arr.length; i++) {
            str += arr[i] + " ";
        }
        System.out.println(str.trim());
    }


    void change_the_elements(int index1, int index2, int[] arr) {
        int temp = arr[index1];
        arr[index1] = arr[index2];
        arr[index2] = temp;
    }

    void bubbleSort(int[] arr) {
        showArray(arr);
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = arr.length - 1; j > i; j--) {
                if (arr[j] < arr[j - 1]) {
                    change_the_elements(j, j - 1, arr);
                }
            }
            showArray(arr);
        }
    }

    public void insertSort(int[] arr) {
        showArray(arr);
        for (int i = arr.length - 2; i >= 0; i--) {
            int element = arr[i];
            int step = 1;
            while (element > arr[i + step]) {
                change_the_elements(i + step - 1, i + step, arr);
                step++;
                if (i + step > arr.length - 1) {
                    break;
                }
            }
            showArray(arr);
        }
    }

    public void selectSort(int[] arr) {
        showArray(arr);
        for (int i = arr.length; i > 1; i--) {
            int max = arr[i - 1];
            int max_index = i - 1;
            for (int j = 0; j < i; j++) {
                if (arr[j] > max) {
                    max = arr[j];
                    max_index = j;
                }
            }
            change_the_elements(i-1, max_index, arr);
            showArray(arr);
        }
    }

}
package lab11;

public interface IWithName
{
    String getName();
}

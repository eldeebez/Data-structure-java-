package lab3v2;


public class Link{
    public String ref;
    public Link(String ref) {
        this.ref=ref;
    }
    @Override
    public boolean equals(Object obj) {
        Link l = (Link) obj;
        return this.ref.equals(l.ref);
    }

}
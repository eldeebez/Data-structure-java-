package lab3v2;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;


public class TwoWayUnorderedListWithHeadAndTail<E> implements IList<E> {

    private class Element {
        public Element(E e) {
            this.object = e;
        }

        public Element(E e, Element next, Element prev) {
            this.object = e;
            this.next = next;
            this.prev = prev;
        }

        E object;
        Element next = null;
        Element prev = null;
    }

    Element head;
    Element tail;
    // can be realization with the field size or without
    int size;

    private class InnerIterator implements Iterator<E> {
        Element pos;
        // TODO maybe more fields....

        public InnerIterator() {
            pos = head;
        }

        @Override
        public boolean hasNext() {
            return pos.next != null;
        }

        @Override
        public E next() {
            pos = pos.next;
            return pos.object;
        }
    }

    private class InnerListIterator implements ListIterator<E> {
        Element p;
        // TODO maybe more fields....

        public InnerListIterator() {
            p = head;
        }

        @Override
        public void add(E e) {
            throw new UnsupportedOperationException();

        }

        @Override
        public boolean hasNext() {
            return p.next != null;
        }

        @Override
        public boolean hasPrevious() {
            return p.prev != null;
        }

        @Override
        public E next() {
            p = p.next;
            return p.object;
        }

        @Override
        public int nextIndex() {
            throw new UnsupportedOperationException();
        }

        @Override
        public E previous() {
            p = p.prev;
            return p.object;
        }

        @Override
        public int previousIndex() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();

        }

        @Override
        public void set(E e) {
            p.object = e;
        }
    }

    public TwoWayUnorderedListWithHeadAndTail() {
        // make a head and a tail
        head = null;
        tail = null;
    }

    @Override
    public boolean add(E e) {
        Element addedElement = new Element(e);
        if (size() == 0) {
            head = addedElement;
            tail = addedElement;
            return true;
        }
        if (size() == 1) {
            tail = addedElement;
            head.next = tail;
            tail.prev = head;
            return true;
        }
        Element secondLast = tail;
        tail = addedElement;
        secondLast.next = tail;
        tail.prev = secondLast;
        return true;
    }

    @Override
    public void add(int index, E element) throws NoSuchElementException {
        if (index < 0 || index > size()) {
            throw new NoSuchElementException();
        }
        Element addedElement = new Element(element);
        if (index == size()) {
            add(element);
            return;
        }
        if (index == 0) {
            Element second = head;
            head = addedElement;
            second.prev = head;
            head.next = second;
            return;
        }
        int currentIndex = 1;
        Element currentElement = head.next;
        while (currentIndex != index) {
            currentIndex++;
            currentElement = currentElement.next;
        }
        addedElement.prev = currentElement.prev;
        currentElement.prev.next = addedElement;
        addedElement.next = currentElement;
        currentElement.prev = addedElement;
    }

    @Override
    public void clear() {
        head = null;
        tail = null;
    }

    @Override
    public boolean contains(E element) {
        Element current = head;
        for (int i = 0; i < size(); i++) {
            if (current.object.equals(element)) {
                return true;
            }
            current = current.next;
        }
        return false;
    }

    @Override
    public E get(int index) throws NoSuchElementException {
        if (index < 0 || index >= size()) {
            throw new NoSuchElementException();
        }
        Element current = head;
        for (int i = 0; i < size(); i++) {
            if (i == index) {
                return current.object;
            }
            current = current.next;
        }
        return null;
    }

    @Override
    public E set(int index, E element) throws NoSuchElementException {
        if (index < 0 || index >= size()) {
            throw new NoSuchElementException();
        }
        Element setElement = new Element(element);
        Element currentElement = head.next;
        int currentIndex = 1;
        if (index == 0) {
            Element removed = head;
            head = setElement;
            head.next = removed.next;
            removed.next.prev = head;
            return removed.object;
        }
        if (index == size() - 1) {
            Element removed = tail;
            tail = setElement;
            tail.prev = removed.prev;
            removed.prev.next = tail;
            return removed.object;
        }

        while (currentIndex != index) {
            currentElement = currentElement.next;
            currentIndex++;
        }
        Element removed = currentElement;
        setElement.prev = removed.prev;
        removed.prev.next = setElement;
        setElement.next = removed.next;
        removed.next.prev = setElement;
        return removed.object;
    }

    @Override
    public int indexOf(E element) {
        Element currentElement = head;
        for (int i = 0; i < size(); i++) {
            if (currentElement.object.equals(element)) {
                return i;
            }
            currentElement = currentElement.next;
        }
        return -1;
    }

    @Override
    public boolean isEmpty() {
        return size() == 0;
    }

    @Override
    public Iterator<E> iterator() {
        return new InnerIterator();
    }

    @Override
    public ListIterator<E> listIterator() {
        throw new UnsupportedOperationException();
    }

    @Override
    public E remove(int index) throws NoSuchElementException {
        if (index < 0 || index >= size()) {
            throw new NoSuchElementException();
        }
        if (size() == 1) {
            Element removed = head;
            clear();
            return removed.object;
        }
        if (index == 0) {
            Element removed = head;
            head = head.next;
            head.prev = null;
            return removed.object;
        }
        if (index == size() - 1) {
            Element removed = tail;
            tail = tail.prev;
            tail.next = null;
            return removed.object;
        }
        Element currentElement = head.next;
        int currentIndex = 1;
        while (currentIndex != index) {
            currentElement = currentElement.next;
            currentIndex++;
        }
        Element removed = currentElement;
        currentElement.prev.next = currentElement.next;
        currentElement.next.prev = currentElement.prev;
        return removed.object;
    }

    @Override
    public boolean remove(E e) {
        if (!contains(e)) {
            return false;
        }
        int i = indexOf(e);
        remove(i);
        return true;
    }

    @Override
    public int size() {
        if (head == null) {
            return 0;
        }
        if (head == tail) {
            return 1;
        }
        Element currentElement = head.next;
        int currentIndex = 1;
        while (currentElement != tail) {
            currentElement = currentElement.next;
            currentIndex++;
        }
        currentIndex++;
        return currentIndex;
    }

    public String toStringReverse() {
        ListIterator<E> iter = new InnerListIterator();
        if (isEmpty()) {
            return "";
        }
        if (this.size() == 1) {
            return "\n" + ((Link) head.object).ref;
        }
        while (iter.hasNext()) {
            iter.next();
        }
        String retStr = "";
        iter.previous();
        retStr += "\n" + ((Link) iter.next()).ref;
        while (iter.hasPrevious()) {
            retStr += "\n" + ((Link) iter.previous()).ref;
        }
        //TODO use reverse direction of the iterator
        return retStr;
    }

    public void add(TwoWayUnorderedListWithHeadAndTail<E> other) {
        if (other.isEmpty()) {
            return;
        } else if (this.isEmpty()) {
            head = other.head;
            tail = other.tail;
            other.clear();
        } else if (other != this) {
            tail.next = other.head;
            other.head.prev = tail;
            tail = other.tail;
            other.clear();
        }
    }
}


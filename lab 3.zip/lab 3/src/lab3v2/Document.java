package lab3v2;

import java.util.Iterator;
import java.util.Scanner;

public class Document {
    public String name;
    public TwoWayUnorderedListWithHeadAndTail<Link> link;

    public Document(String name, Scanner scan) {
        this.name = name;
        link = new TwoWayUnorderedListWithHeadAndTail<Link>();
        load(scan);
    }

    public void load(Scanner scan) {
        while (scan.hasNextLine()) {
            String s = scan.nextLine().toLowerCase();
            if (s.equalsIgnoreCase("eod")) {
                return;
            }
            String[] words = s.split(" ");
            for (String word : words) {
//                System.out.println("-" + word);
                if (word.startsWith("link=")) {
                    if (correctLink(word.substring(5))) {
                        link.add(new Link(word.substring(5)));
//                        System.out.println("Link " + new Link(word.substring(5)).ref);
                    }
                }
            }
        }
    }

    // accepted only small letters, capitalic letter, digits nad '_' (but not on the begin)
    public static boolean correctLink(String link) {
        if (link.length() == 0) {
            return false;
        }
        if ((int) link.charAt(0) >= 97 && (int) link.charAt(0) <= 122) {
            for (int i = 0; i < link.length(); i++) {
                int ascii = (int) link.charAt(i);
                if (!((ascii >= 97 && ascii <= 122) || ascii == 95 || (ascii >= 48 && ascii <= 57))) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        String str = "Document: " + name;
        Iterator<Link> iterator = link.iterator();
        if(!link.isEmpty()) {
            str += "\n" + link.get(0).ref;
        }
        while (!link.isEmpty() && iterator.hasNext()) {
            str += "\n" + iterator.next().ref;
        }
        return str;
    }

    public String toStringReverse() {
        String retStr = "Document: " + name;
        if (!link.isEmpty()) {
            return retStr + link.toStringReverse();
        } else {
            return retStr;
        }
    }

}
package lab7;
public interface IWithName{
    String getName();
}

package dsaa.lab04;

import java.util.ListIterator;
import java.util.Scanner;

public class Document{
    public String name;
    public TwoWayCycledOrderedListWithSentinel<Link> link;
    public Document(String name, Scanner scan) {
        this.name=name.toLowerCase();
        link=new TwoWayCycledOrderedListWithSentinel<Link>();
        load(scan);
    }
    public void load(Scanner scan) {
        String line = scan.nextLine();
        String text = "";
        while (!line.equals("eod") || line == "") {
            text += line + " ";
            line = scan.nextLine();
        }
        String[] words = text.split(" ");
        for(String word : words){
            if(word.toLowerCase().startsWith("link=")){
                if(correctLink(word)){
                    link.add(createLink(word.toLowerCase()));
                }
            }
        }
    }


    public static boolean isCorrectId(String id) {
        char[] characters = id.toCharArray();
        boolean correct = false;
        if(characters.length != 0){
            if(Character.isLetter(characters[0])){
                correct = true;
                for(char x : characters){
                    if(!Character.isLetterOrDigit(x) &&  x != '_'){
                        correct = false;
                    }
                }
            }
        }
        return correct;
    }


    private static Link createLink(String link) {
        int index = link.indexOf('(');
        if(index == -1){
            return new Link(link.substring(5, link.length()));
        }
        int weight = Integer.parseInt(link.substring(index+1, link.length()-1));
        return new Link(link.substring(5, index), weight);
    }


    // accepted only small letters, capitalic letter, digits nad '_' (but not on the begin)
    public static boolean correctLink(String link) {
        link = link.substring(5, link.length());
        char[] characters = link.toCharArray();
        boolean correct = false;
        if(characters.length != 0){
            if(Character.isLetterOrDigit(characters[0])){
                correct = true;
                for(char x : characters){
                    if(!Character.isLetterOrDigit(x) &&  x != '_' && x != '(' && x != ')'){
                        correct = false;
                    }
                }
            }
        }
        int index1 = link.indexOf('(');
        int index2 = link.indexOf(')');
        if(index1 != -1){
            correct = false;
        }
        if(index1 != -1 && index2 != -1 && index1 < index2 && index2 == link.length()-1){
            correct = true;
            String weight = link.substring(index1+1, link.length()-1);
            for(char x : weight.toCharArray()){
                if(!Character.isDigit(x)){
                    correct = false;
                }
            }
        }

        return correct;
    }

    @Override
    public String toString() {
        System.out.print("Document: "+name);
        String str = "";
        int j = 10;
        for(int i = 0; i < this.link.size(); i++){
            if(link.get(i) != null){
                if(j == 10){
                    str += "\n";
                    j = 0;
                }
                str +=  link.get(i).ref + "("+link.get(i).weight+") ";
                j++;

            }
        }
        return str;
    }

    public String toStringReverse() {
        String retStr="Document: "+name;
        ListIterator<Link> iter=link.listIterator();
        int j = 10;
        while(iter.hasNext()){
            iter.next();
        }
        while(iter.hasPrevious()){
            if(j == 10){
                retStr += "\n";
                j = 0;
            }
            j++;
            Link item = (Link)iter.previous();
            if (item!=null){
                retStr += item.ref + "("+item.weight+") ";
            }
        }
        return retStr;
    }
}

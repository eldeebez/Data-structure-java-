package dsaa.lab04;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class TwoWayCycledOrderedListWithSentinel<E> implements IList<E>{

    private class Element{
        public Element(E e) {
            this.object=e;
        }
        public Element(E e, Element next, Element prev) {
            this.object=e;
            this.next = next;
            this.prev = prev;
        }
        // add element e after this
        public void addAfter(Element elem) {
            elem.prev = this;
            this.next.prev = elem;
            elem.next = this.next;
            this.next = elem;
        }
        // assert it is NOT a sentinel
        public void remove() {
            if(sentinel != this){
                this.prev.next = this.next;
                this.next.prev = this.prev;
            }
        }
        E object;
        Element next=null;
        Element prev=null;
    }


    Element sentinel;
    int size;

    private class InnerIterator implements Iterator<E>{
        //TODO
        public InnerIterator() {
            //TODO
        }
        @Override
        public boolean hasNext() {
            //TODO
            return false;
        }

        @Override
        public E next() {
            //TODO
            return null;
        }
    }

    private class InnerListIterator implements ListIterator<E>{
        public Element p = new Element(null, sentinel.next, sentinel);
        // TODO maybe more fields....

        @Override
        public void add(E e) {
            throw new UnsupportedOperationException();

        }

        @Override
        public boolean hasNext() {
            // TODO Auto-generated method stub

            return p.next != null && p.next != sentinel;
        }

        @Override
        public boolean hasPrevious() {
            // TODO Auto-generated method stub
            return p.prev != null && p.prev != sentinel;
        }

        @Override
        public E next() {
            // TODO Auto-generated method stub
            p.next = p.next.next;
            p.prev = p.next.prev;
            return p.next.object;
        }

        @Override
        public int nextIndex() {
            throw new UnsupportedOperationException();
        }

        @Override
        public E previous() {
            // TODO Auto-generated method stub
            p.prev = p.prev.prev;
            p.next = p.prev.next;
            return p.next.object;
        }

        @Override
        public int previousIndex() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();

        }

        @Override
        public void set(E e) {
            // TODO Auto-generated method stub

        }
    }
    public TwoWayCycledOrderedListWithSentinel() {
        this.sentinel = new Element(null);
        this.sentinel.next = sentinel;
        this.sentinel.prev = sentinel;
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean add(E e) {
        Element cur = sentinel;
        if(this.size() == 0){
            sentinel.addAfter(new Element(e));
        } else {
            cur = cur.next;
            while( ((Comparable) cur.object).compareTo((Comparable) e) <= 0){
                if(cur.next != sentinel){
                    cur = cur.next;
                } else {
                    cur.next = new Element(e, cur.next, cur);
                    cur.next.next.prev = cur.next;
                    return true;
                }
            }
            cur = cur.prev;
            cur.addAfter(new Element(e));
        }

        return true;
    }

    // private Element getElement(int index) {
    // 	//TODO
    // 	return null;
    // }

    // private Element getElement(E obj) {
    // 	//TODO
    // 	return null;
    // }

    @Override
    public void add(int index, E element) {
        throw new UnsupportedOperationException();

    }

    @Override
    public void clear() {
        sentinel.next = sentinel;
        sentinel.prev = sentinel;
    }

    @Override
    public boolean contains(E element) {
        if(indexOf(element) != -1){
            return true;
        }
        return false;
    }

    @Override
    public E get(int index) throws NoSuchElementException {
        if(index < 0 || index >= this.size()){
            throw new NoSuchElementException();
        }
        Element cur = sentinel;
        int i = -1;
        while(i != index){
            cur = cur.next;
            i++;
        }
        return cur.object;
    }

    @Override
    public E set(int index, E element) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int indexOf(E element) {
        Element cur = sentinel;
        int i = 0;
        if(this.isEmpty()){
            return -1;
        }
        cur = cur.next;
        while(!cur.object.equals(element)){
            if(cur.next == sentinel){
                return -1;
            }
            i++;
            cur = cur.next;
        }
        return i;
    }

    @Override
    public boolean isEmpty() {
        return sentinel.next == sentinel;
    }

    @Override
    public Iterator<E> iterator() {
        return new InnerIterator();
    }

    @Override
    public ListIterator<E> listIterator() {
        return new InnerListIterator();
    }

    @Override
    public E remove(int index) throws NoSuchElementException {
        E buffer = this.get(index);
        Element cur = sentinel;
        int i = -1;
        if(index < 0 || index >= this.size()){
            throw new NoSuchElementException();
        }
        while(i < index-1){
            cur = cur.next;
            i++;
        }
        cur.next = cur.next.next;
        cur.next.prev = cur;
        return buffer;
    }

    @Override
    public boolean remove(E e) {
        if(this.indexOf(e) == -1){
            return false;
        }
        this.remove(this.indexOf(e));
        return true;
    }

    @Override
    public int size() {
        Element cur = sentinel;
        int counter = 0;
        if(this.isEmpty()){
            return 0;
        }
        while(cur.next != sentinel){
            counter++;
            cur = cur.next;
        }

        return counter;
    }

    @SuppressWarnings("unchecked")
    public void add(TwoWayCycledOrderedListWithSentinel<E> other) {
        if(!other.equals(this) && other.size() != 0){
            int s1 = this.size();
            int s2 = other.size();
            Element cur = sentinel;
            Element otherCur = other.sentinel;
            otherCur = otherCur.next;
            for(int i = 0; i <= s1 + s2; i++){
                if(otherCur.object == null){
                    break;
                }
                if(cur.next.object == null){
                    Element x = new Element(otherCur.object);
                    cur.addAfter(x);
                    cur = cur.next;
                    otherCur = otherCur.next;
                }
                else if(((Comparable) cur.next.object).compareTo((Comparable) otherCur.object) > 0){
                    Element x = new Element(otherCur.object);
                    cur.addAfter(x);
                    otherCur = otherCur.next;
                    if(cur.next.object != null){
                        cur = cur.next;
                    }
                }
                else {
                    cur = cur.next;
                }

            }
        }
        other.clear();
    }


    //@SuppressWarnings({ "unchecked", "rawtypes" })
    public void removeAll(E e) {
        while(indexOf(e) != -1){
            this.remove(indexOf(e));
        }
    }

}

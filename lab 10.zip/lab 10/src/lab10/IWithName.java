package lab10;

public interface IWithName
{
    String getName();
}
